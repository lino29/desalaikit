<?php

defined('BASEPATH') or exit('No direct script access allowed');

$this->load->view("$folder_themes/template");

?>
