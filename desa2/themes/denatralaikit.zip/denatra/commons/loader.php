<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<?php if (in_array($this->uri->segment(1), ['', 'first']) && (in_array($this->uri->segment(2), ['']))): ?>
<div class="loader justify-content-center">
	<div class="align-self-center text-center">
		<div class="logo-img-loader">
			<img src="https://desalaikit.com/desa/logo/logo_minut_gif__sid__fsKzi46.gif">
		</div>
	</div>
</div>
<?php endif; ?>

