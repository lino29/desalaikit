<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!--
<?php if (in_array($this->uri->segment(1), ['', 'first']) && (in_array($this->uri->segment(2), ['']))): ?>
<div class="loader justify-content-center">
	<div class="align-self-center text-center">
		<div class="logo-img-loader">
			<div class="spinner"></div>
		</div>
	</div>
</div>
<?php endif; ?>
-->
